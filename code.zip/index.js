const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config()
console.log(process.env)
const wagner = require('wagner-core');

//ssh -i Ubuntu-NodeJsServer_key.pem azureuser@20.87.219.143
var PORT = 4000;
if (process.env.SERVER_ENV == "PROD"){
    PORT = 80;
}else{
    PORT=4000;
}


const app = express();

main().catch(err => console.log(err));

async function main() {
    await mongoose.connect("mongodb+srv://appuser:tJiu0Ziy00tf9ktL@cluster0.ivtjs.mongodb.net/?retryWrites=true&w=majority");
    
    // use `await mongoose.connect('mongodb://user:password@127.0.0.1:27017/test');` if your database has auth enabled
  }


app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true }));

app.get('/', async (req, res)=>{
    res.send('hello world');
})

app.post('/sellmycar', (req, res)=>{
    const Lead = mongoose.model('Lead', require('./schema/leads.js'), 'leads');
    const sellCarLead = new Lead(req.body);
    sellCarLead.save().then((doc)=>{
        console.log(doc)
        res.send(doc);
    }).catch((err)=>{
        console.log(err);
    })
});

app.post('/sellmycarleads', async(req, res)=>{
    const Lead = mongoose.model('Lead', require('./schema/leads.js'), 'leads');
    const sellCarLead = new Lead(req.body);
    sellCarLead.save().then((doc)=>{
        console.log(doc)
        res.send(doc);
    }).catch((err)=>{
        console.log(err);
    })
});

app.post('/reportaccident', async (req, res)=>{
    console.log(req.body);
    const Accident = mongoose.model('Accident', require('./schema/accidents.js'), 'accidents');
    const accident = await new Accident(req.body);
    console.log(accident);
try {
    
    await accident.save();
    res.json({msg: 'Towing is being arranged'})
} catch (error) {
    res.json(error);
}

    
});

app.listen(PORT, ()=>{
    console.log(`listening on port ${PORT}`);
});